new Vue({
    el: '#login',
    data: {
        username: null,
        password: null,
        message: null,
    },
    mounted: function() {
        logged = localStorage.getItem('loggedin')
        if (logged !== null){
            window.location.href = 'home.html'
        }
    },
    methods: {
        signUp() {
            axios.post('http://localhost:5000/',
            {
                username: this.username,
                password: this.password,
            })
            .then(response => {this.message = response.data})
        },
        signIn() {
            axios.post('http://localhost:5000/signin', 
            {
                username: this.username,
                password: this.password,
            })
            .then(response => 
                {
                    if (response.data != '0') 
                        {
                            localStorage.setItem('loggedin', response.data)
                            window.location.href = 'home.html'
                        }
                    else {
                        this.message = `Invalid Inputs` ;
                    }
                })
        },
    },
})