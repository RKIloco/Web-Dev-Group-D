new Vue({
    el: '#edit',
    data: {
        items: [],
        bought_id: null,
        name: null,
        price: null,
        image: null,
        message: null,
    },
    mounted: function() {
        axios({
            method: 'get',
            url: 'http://localhost:5000/youritems'
        })
        .then(response => {this.items = response.data})
    },
    methods: {
        editItem() {
            axios.post('http://localhost:5000/edit',
            {
                name: this.name,
                price: this.price,
                image: this.image,
                bought_id: this.bought_id,
            })
            .then(response => {
                this.message = response.data
            })
        },
        deleteItem() {
            axios.post('http://localhost:5000/delete',
            {
                bought_id: this.bought_id,
            })
            .then(response => {
                this.message = response.data
            })
        },
        logOut() {
            axios.post('http://localhost:5000/logout',
            {
                logged: "0",
            })
            .then(response => {
                localStorage.clear();
                window.location.href = 'login.html'
            })
        },
    },
})