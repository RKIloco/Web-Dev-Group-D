new Vue({
    el: '#about',
    data: {
    },
    mounted: function() {
        logged = localStorage.getItem('loggedin')
        if (logged == null){
            window.location.href = 'login.html'
        }
    },
    methods: {
        logOut() {
            axios.post('http://localhost:5000/logout',
            {
                logged: "0",
            })
            .then(response => {
                localStorage.clear();
                window.location.href = 'login.html'
            })
        },
    },
})