new Vue({
    el: '#home',
    data: {
        username: null,
        password: null,
        message: null,
    },
    mounted: function() {
        logged = localStorage.getItem('loggedin')
        if (logged === null){
            window.location.href = 'login.html'
        }
    },
    methods: {
        logOut: function() {
            localStorage.clear();
        },
    },
})