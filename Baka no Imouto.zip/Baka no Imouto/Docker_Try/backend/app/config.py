
class Configuration:
    SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://root:root@database/itemsdatabase'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

